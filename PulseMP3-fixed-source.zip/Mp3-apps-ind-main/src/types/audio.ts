export interface AudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  src: string; // URL or Blob URI
  size?: number; // bytes
  dateAdded: number; // timestamp
  albumArt?: string; // image URL or data URI
  genre?: string;
  isFavorite: boolean;
  bitrate?: string;
  format?: 'MP3' | 'WAV' | 'FLAC' | 'AAC' | 'OGG' | 'M4A' | 'SYNTH';
  sampleRate?: string;
  lyrics?: string;
  year?: number;
  isCustom?: boolean;
  folder?: string;
  path?: string;
  uri?: string;
}

export type RepeatMode = 'off' | 'all' | 'one';

export interface EqualizerBand {
  frequency: number;
  label: string;
  gain: number; // -12dB to +12dB
}

export interface EqualizerPreset {
  id: string;
  name: string;
  gains: number[]; // 5 band values in dB
}

export interface Playlist {
  id: string;
  name: string;
  trackIds: string[];
  createdAt: number;
  coverArt?: string;
  description?: string;
}

export type SortField = 'title' | 'artist' | 'album' | 'duration' | 'dateAdded' | 'size';
export type SortOrder = 'asc' | 'desc';

export interface SortOption {
  field: SortField;
  order: SortOrder;
  label: string;
}

export type MainTab = 'songs' | 'device' | 'playlists' | 'folders' | 'albums' | 'artists';
