import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useRef,
  useCallback,
} from 'react';
import {
  AudioTrack,
  RepeatMode,
  Playlist,
  EqualizerPreset,
} from '../types/audio';
import {
  INITIAL_TRACKS,
  EQUALIZER_PRESETS,
  EQUALIZER_BANDS,
} from '../data/mockTracks';
import { generateDemoTrack, getInstantFallbackAudio } from '../utils/audioGenerator';
import { getAudioBlob, deleteAudioBlob } from '../utils/audioMetadata';
import { DeviceAudio } from '../utils/nativeDeviceAudio';

interface AudioPlayerContextType {
  // Library
  tracks: AudioTrack[];
  favorites: AudioTrack[];
  playlists: Playlist[];
  toggleFavorite: (trackId: string) => void;
  addTracks: (newTracks: AudioTrack[]) => void;
  updateTrack: (trackId: string, updates: Partial<AudioTrack>) => void;
  deleteTrack: (trackId: string) => void;
  createPlaylist: (name: string, description?: string) => void;
  addTrackToPlaylist: (playlistId: string, trackId: string) => void;
  removeTrackFromPlaylist: (playlistId: string, trackId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  scanLocalDeviceStorage: () => Promise<number>;

  // Playback State
  currentTrack: AudioTrack | null;
  isPlaying: boolean;
  isBuffering: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  playbackRate: number;
  repeatMode: RepeatMode;
  isShuffle: boolean;
  queue: AudioTrack[];

  // Controls
  playTrack: (track: AudioTrack, newQueue?: AudioTrack[]) => void;
  togglePlayPause: () => void;
  playNext: () => void;
  playPrevious: () => void;
  seekTo: (timeInSeconds: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  setPlaybackRate: (rate: number) => void;
  toggleRepeatMode: () => void;
  toggleShuffle: () => void;
  addToQueue: (track: AudioTrack) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;

  // Equalizer
  eqEnabled: boolean;
  toggleEq: () => void;
  eqGains: number[];
  setEqBandGain: (index: number, gain: number) => void;
  selectedPresetId: string;
  applyEqPreset: (presetId: string) => void;
  getFrequencyData: () => Uint8Array;

  // Sleep Timer
  sleepTimerMinutes: number | null;
  sleepTimerRemaining: number | null; // seconds
  setSleepTimer: (minutes: number | null) => void;

  // Modals & Screen States
  isFullPlayerOpen: boolean;
  openFullPlayer: () => void;
  closeFullPlayer: () => void;
  detailsTrack: AudioTrack | null;
  openDetails: (track: AudioTrack) => void;
  closeDetails: () => void;
  isEqualizerOpen: boolean;
  openEqualizer: () => void;
  closeEqualizer: () => void;
  isSpeedDialogOpen: boolean;
  openSpeedDialog: () => void;
  closeSpeedDialog: () => void;
  isSleepTimerDialogOpen: boolean;
  openSleepTimerDialog: () => void;
  closeSleepTimerDialog: () => void;
  isPlaylistModalOpen: boolean;
  playlistTrackToAdd: AudioTrack | null;
  openPlaylistModal: (track?: AudioTrack) => void;
  closePlaylistModal: () => void;
  isQueueDrawerOpen: boolean;
  openQueueDrawer: () => void;
  closeQueueDrawer: () => void;
  isPermissionsModalOpen: boolean;
  openPermissionsModal: () => void;
  closePermissionsModal: () => void;
  audioPermissionGranted: boolean;
  setAudioPermissionGranted: (granted: boolean) => void;
  notificationPermissionGranted: boolean;
  requestNotificationPermission: () => Promise<boolean>;
}

const AudioPlayerContext = createContext<AudioPlayerContextType | null>(null);

const STORAGE_KEY_TRACKS = 'pulse_mp3_tracks';
const STORAGE_KEY_PLAYLISTS = 'pulse_mp3_playlists';
const STORAGE_KEY_EQ = 'pulse_mp3_eq_gains';

export const AudioPlayerProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // 1. Audio element & Web Audio API refs
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<MediaElementAudioSourceNode | null>(null);
  const eqFiltersRef = useRef<BiquadFilterNode[]>([]);
  const analyserRef = useRef<AnalyserNode | null>(null);

  // 2. Library state
  const [tracks, setTracks] = useState<AudioTrack[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_TRACKS);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Strictly deduplicate anything loaded from localStorage
          const seen = new Set<string>();
          const deduped: AudioTrack[] = [];
          const removedTrackIds = new Set(['track-remix-1', 'track-remix-2', 'track-remix-3', 'track-remix-4']);
          for (const item of parsed) {
            if (item && item.id && !removedTrackIds.has(item.id) && !seen.has(item.id)) {
              seen.add(item.id);
              deduped.push(item);
            }
          }
          return deduped;
        }
      }
    } catch {
      // ignore
    }
    return INITIAL_TRACKS;
  });

  const [playlists, setPlaylists] = useState<Playlist[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_PLAYLISTS);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [
      {
        id: 'pl-favorites',
        name: 'Liked Hits',
        description: 'Your favorite tracks',
        trackIds: ['track-1', 'track-2', 'track-5'],
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 10,
        coverArt:
          'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80',
      },
      {
        id: 'pl-chill',
        name: 'Late Night Chill',
        description: 'Mellow beats and relaxing melodies',
        trackIds: ['track-2', 'track-4', 'track-5'],
        createdAt: Date.now() - 1000 * 60 * 60 * 24 * 5,
        coverArt:
          'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80',
      },
    ];
  });

  // 3. Playback state
  const [currentTrack, setCurrentTrack] = useState<AudioTrack | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolumeState] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [playbackRate, setPlaybackRateState] = useState<number>(1.0);
  const [repeatMode, setRepeatMode] = useState<RepeatMode>('all');
  const [isShuffle, setIsShuffle] = useState<boolean>(false);
  const [queue, setQueue] = useState<AudioTrack[]>([]);

  // 4. Equalizer state
  const [eqEnabled, setEqEnabled] = useState<boolean>(true);
  const [eqGains, setEqGains] = useState<number[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_EQ);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [0, 0, 0, 0, 0];
  });
  const [selectedPresetId, setSelectedPresetId] = useState<string>('flat');

  // 5. Sleep timer state
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemaining, setSleepTimerRemaining] = useState<number | null>(null);

  // 6. Modal / View states
  const [isFullPlayerOpen, setIsFullPlayerOpen] = useState<boolean>(false);
  const [detailsTrack, setDetailsTrack] = useState<AudioTrack | null>(null);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState<boolean>(false);
  const [isSpeedDialogOpen, setIsSpeedDialogOpen] = useState<boolean>(false);
  const [isSleepTimerDialogOpen, setIsSleepTimerDialogOpen] = useState<boolean>(false);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState<boolean>(false);
  const [playlistTrackToAdd, setPlaylistTrackToAdd] = useState<AudioTrack | null>(null);
  const [isQueueDrawerOpen, setIsQueueDrawerOpen] = useState<boolean>(false);
  const [isPermissionsModalOpen, setIsPermissionsModalOpen] = useState<boolean>(false);
  const [audioPermissionGranted, setAudioPermissionGrantedState] = useState<boolean>(() => {
    try {
      return localStorage.getItem('pulse_mp3_audio_permission') === 'true';
    } catch {
      return false;
    }
  });
  const [notificationPermissionGranted, setNotificationPermissionGranted] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission === 'granted';
    }
    return false;
  });

  // Frequency array for analyser
  const frequencyDataArray = useRef<Uint8Array | null>(null);

  // Initialize Audio element and default track generation
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'metadata';
    audio.volume = 0.85;
    audioRef.current = audio;

    // Set initial track and queue
    if (tracks.length > 0) {
      const defaultTrack = tracks.find((t) => t.id === 'track-remix-8') || tracks[0];
      setCurrentTrack(defaultTrack);
      setQueue(tracks);
    }

    // Generate real audio for initial demo tracks in background
    const initDemoAudio = async () => {
      const themes: ('synthwave' | 'lofi' | 'electronic' | 'acoustic' | 'ambient' | 'synthwave')[] = [
        'synthwave',
        'lofi',
        'electronic',
        'acoustic',
        'ambient',
        'synthwave',
      ];

      setTracks((prev) => {
        return prev.map((t, idx) => {
          if (!t.src) {
            // Placeholder theme
            return { ...t };
          }
          return t;
        });
      });

      // Generate audio blobs asynchronously
      for (let i = 0; i < Math.min(6, tracks.length); i++) {
        const theme = themes[i % themes.length];
        try {
          const generatedUrl = await generateDemoTrack(theme, 45 + (i % 3) * 10);
          setTracks((currTracks) => {
            const updated = currTracks.map((trk, idx) => {
              if (idx === i && !trk.src) {
                return { ...trk, src: generatedUrl };
              }
              return trk;
            });
            return updated;
          });

          // Also update currentTrack src if it's the one
          setCurrentTrack((curr) => {
            if (curr && curr.id === tracks[i].id && !curr.src) {
              return { ...curr, src: generatedUrl };
            }
            return curr;
          });
        } catch (e) {
          console.warn('Could not generate track audio buffer', e);
        }
      }
    };

    initDemoAudio();

    // Rehydrate any persisted downloaded/custom tracks from IndexedDB
    const rehydratePersistedCustomTracks = async () => {
      try {
        const storedTracksJson = localStorage.getItem(STORAGE_KEY_TRACKS);
        if (!storedTracksJson) return;
        const parsed = JSON.parse(storedTracksJson);
        if (!Array.isArray(parsed)) return;

        const customTracks = parsed.filter(
          (t: AudioTrack) => (t.isCustom || t.id.startsWith('device-') || t.id.startsWith('local-')) && !t.src
        );

        if (customTracks.length === 0) return;

        const rehydrated = await Promise.all(
          customTracks.map(async (t: AudioTrack) => {
            const blob = await getAudioBlob(t.id);
            if (blob) {
              return { id: t.id, url: URL.createObjectURL(blob) };
            }
            return null;
          })
        );

        const validUrls = rehydrated.filter((r): r is { id: string; url: string } => r !== null);
        if (validUrls.length > 0) {
          const urlMap = new Map(validUrls.map((item) => [item.id, item.url]));
          setTracks((prev) =>
            prev.map((trk) => (urlMap.has(trk.id) ? { ...trk, src: urlMap.get(trk.id)! } : trk))
          );
        }
      } catch (err) {
        console.debug('Custom track rehydration notice:', err);
      }
    };

    rehydratePersistedCustomTracks();

    return () => {
      audio.pause();
      audio.src = '';
    };
  }, []);

  // Web Audio Context initialization on first play gesture
  const initWebAudio = useCallback(() => {
    if (audioContextRef.current || !audioRef.current) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      const source = ctx.createMediaElementSource(audioRef.current);
      sourceNodeRef.current = source;

      // Create 5-band equalizer filters
      const filters = EQUALIZER_BANDS.map((band, idx) => {
        const filter = ctx.createBiquadFilter();
        if (idx === 0) {
          filter.type = 'lowshelf';
        } else if (idx === EQUALIZER_BANDS.length - 1) {
          filter.type = 'highshelf';
        } else {
          filter.type = 'peaking';
          filter.Q.value = 1.0;
        }
        filter.frequency.value = band.frequency;
        filter.gain.value = eqEnabled ? eqGains[idx] : 0;
        return filter;
      });
      eqFiltersRef.current = filters;

      // Connect filter chain
      let prevNode: AudioNode = source;
      filters.forEach((filter) => {
        prevNode.connect(filter);
        prevNode = filter;
      });

      // Create Analyser for real visualizer
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 64;
      analyser.smoothingTimeConstant = 0.8;
      analyserRef.current = analyser;
      frequencyDataArray.current = new Uint8Array(analyser.frequencyBinCount);

      prevNode.connect(analyser);
      analyser.connect(ctx.destination);
    } catch (err) {
      console.warn('Web Audio API could not be connected:', err);
    }
  }, [eqEnabled, eqGains]);

  // Sync EQ gains with Web Audio nodes
  useEffect(() => {
    if (eqFiltersRef.current.length === 5) {
      eqFiltersRef.current.forEach((filter, idx) => {
        filter.gain.value = eqEnabled ? eqGains[idx] || 0 : 0;
      });
    }
    localStorage.setItem(STORAGE_KEY_EQ, JSON.stringify(eqGains));
  }, [eqGains, eqEnabled]);

  // Audio event listeners
  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleDurationChange = () => {
      if (audio.duration && !isNaN(audio.duration)) {
        setDuration(audio.duration);
      }
    };

    const handlePlay = () => {
      setIsPlaying(true);
      setIsBuffering(false);
    };

    const handlePause = () => {
      setIsPlaying(false);
    };

    const handleWaiting = () => {
      setIsBuffering(true);
    };

    const handleCanPlay = () => {
      setIsBuffering(false);
    };

    const handleEnded = () => {
      if (repeatMode === 'one') {
        audio.currentTime = 0;
        audio.play().catch(() => {});
      } else {
        playNext();
      }
    };

    const handleError = () => {
      console.warn('Audio element error detected, auto-recovering...');
      setIsBuffering(false);
      try {
        const fallback = getInstantFallbackAudio();
        audio.src = fallback;
        audio.play().catch(() => {});
      } catch {
        // ignore
      }
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('durationchange', handleDurationChange);
    audio.addEventListener('play', handlePlay);
    audio.addEventListener('pause', handlePause);
    audio.addEventListener('waiting', handleWaiting);
    audio.addEventListener('canplay', handleCanPlay);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('durationchange', handleDurationChange);
      audio.removeEventListener('play', handlePlay);
      audio.removeEventListener('pause', handlePause);
      audio.removeEventListener('waiting', handleWaiting);
      audio.removeEventListener('canplay', handleCanPlay);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [repeatMode]);

  // Save tracks & playlists to localStorage
  useEffect(() => {
    try {
      const serializableTracks = tracks.map((t) => ({
        ...t,
        src: t.src && t.src.startsWith('blob:') ? '' : t.src,
      }));
      localStorage.setItem(STORAGE_KEY_TRACKS, JSON.stringify(serializableTracks));
    } catch (e) {
      console.warn('LocalStorage quota warning:', e);
    }
  }, [tracks]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY_PLAYLISTS, JSON.stringify(playlists));
    } catch {
      // ignore
    }
  }, [playlists]);

  // Sleep Timer countdown
  useEffect(() => {
    if (sleepTimerRemaining === null) return;
    if (sleepTimerRemaining <= 0) {
      if (audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
      setSleepTimerMinutes(null);
      setSleepTimerRemaining(null);
      return;
    }

    const interval = setInterval(() => {
      setSleepTimerRemaining((prev) => {
        if (prev === null || prev <= 1) {
          if (audioRef.current) audioRef.current.pause();
          setIsPlaying(false);
          setSleepTimerMinutes(null);
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerRemaining]);

  // Play a track
  const playTrack = useCallback(
    async (track: AudioTrack, newQueue?: AudioTrack[]) => {
      initWebAudio();
      if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
        audioContextRef.current.resume().catch(() => {});
      }

      if (newQueue) {
        setQueue(newQueue);
      } else if (!queue.some((t) => t.id === track.id)) {
        setQueue((prev) => [track, ...prev]);
      }

      // 1. Try native Kotlin playback if available on mobile device
      let playedViaNative = false;
      if (track.uri?.startsWith('content://') || track.path?.startsWith('/storage/')) {
        try {
          const nativeRes = await DeviceAudio.playDeviceAudio({
            uri: track.uri,
            filePath: track.path,
          });
          if (nativeRes && nativeRes.success) {
            playedViaNative = true;
            setIsPlaying(true);
            if (nativeRes.duration) {
              setDuration(nativeRes.duration);
            }
          }
        } catch {
          // Native playback unavailable or not running inside native shell, use standard Web Audio pipeline
        }
      }

      // 2. Standard Web Audio / HTML5 audio playback (supports browser, PWA, and local fallback)
      if (!playedViaNative) {
        let audioSrc = track.src;

        // If track src is missing (e.g. after refresh), retrieve blob from IndexedDB
        if (!audioSrc || audioSrc === '') {
          try {
            const storedBlob = await getAudioBlob(track.id);
            if (storedBlob) {
              audioSrc = URL.createObjectURL(storedBlob);
              updateTrack(track.id, { src: audioSrc });
            }
          } catch {
            // ignore
          }
        }

        // If still no valid audioSrc, provide instant fallback audio loop
        if (!audioSrc || audioSrc === '') {
          audioSrc = getInstantFallbackAudio(track.id);
        }

        const updatedTrack = { ...track, src: audioSrc };
        setCurrentTrack(updatedTrack);

        if (audioRef.current) {
          audioRef.current.src = audioSrc;
          audioRef.current.playbackRate = playbackRate;
          audioRef.current.currentTime = 0;
          try {
            await audioRef.current.play();
            setIsPlaying(true);
          } catch (err) {
            console.warn('Playback error or user gesture required:', err);
            // If failed because of expired blob url, try loading from IndexedDB
            try {
              const storedBlob = await getAudioBlob(track.id);
              if (storedBlob && audioRef.current) {
                const refreshedUrl = URL.createObjectURL(storedBlob);
                audioRef.current.src = refreshedUrl;
                await audioRef.current.play();
                setIsPlaying(true);
                updateTrack(track.id, { src: refreshedUrl });
                return;
              }
            } catch {
              // ignore
            }
            // Final fallback
            try {
              const fallback = getInstantFallbackAudio(track.id);
              if (audioRef.current) {
                audioRef.current.src = fallback;
                await audioRef.current.play();
                setIsPlaying(true);
              }
            } catch {
              // ignore
            }
          }
        }
      }
    },
    [initWebAudio, queue, playbackRate]
  );

  // Play/Pause toggle
  const togglePlayPause = useCallback(async () => {
    initWebAudio();
    if (audioContextRef.current && audioContextRef.current.state === 'suspended') {
      audioContextRef.current.resume().catch(() => {});
    }

    if (isPlaying) {
      try {
        await DeviceAudio.pauseDeviceAudio();
      } catch {
        // ignore
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
      setIsPlaying(false);
    } else {
      let resumedNative = false;
      try {
        const res = await DeviceAudio.resumeDeviceAudio();
        if (res && res.isPlaying) {
          resumedNative = true;
          setIsPlaying(true);
        }
      } catch {
        // ignore
      }

      if (!resumedNative) {
        if (!currentTrack && tracks.length > 0) {
          playTrack(tracks[0]);
        } else if (currentTrack && (!audioRef.current?.src || audioRef.current.src === '' || audioRef.current.src === window.location.href)) {
          playTrack(currentTrack);
        } else if (audioRef.current) {
          audioRef.current.play().catch((e) => {
            console.warn('Playback error, falling back to playTrack:', e);
            if (currentTrack) playTrack(currentTrack);
          });
        }
      }
    }
  }, [isPlaying, currentTrack, tracks, playTrack, initWebAudio]);

  // Play Next
  const playNext = useCallback(() => {
    const list = queue.length > 0 ? queue : tracks;
    if (list.length === 0) return;

    if (isShuffle) {
      const randomIndex = Math.floor(Math.random() * list.length);
      playTrack(list[randomIndex]);
      return;
    }

    const currentIndex = list.findIndex((t) => t.id === currentTrack?.id);
    if (currentIndex === -1 || currentIndex >= list.length - 1) {
      if (repeatMode === 'all') {
        playTrack(list[0]);
      }
    } else {
      playTrack(list[currentIndex + 1]);
    }
  }, [queue, tracks, isShuffle, currentTrack, repeatMode, playTrack]);

  // Play Previous
  const playPrevious = useCallback(() => {
    if (audioRef.current && audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      return;
    }

    const list = queue.length > 0 ? queue : tracks;
    if (list.length === 0) return;

    const currentIndex = list.findIndex((t) => t.id === currentTrack?.id);
    if (currentIndex <= 0) {
      playTrack(list[list.length - 1]);
    } else {
      playTrack(list[currentIndex - 1]);
    }
  }, [queue, tracks, currentTrack, playTrack]);

  // Seek
  const seekTo = useCallback(async (timeInSeconds: number) => {
    try {
      await DeviceAudio.seekDeviceAudio({ position: timeInSeconds });
    } catch {
      // ignore
    }
    if (audioRef.current) {
      audioRef.current.currentTime = timeInSeconds;
      setCurrentTime(timeInSeconds);
    }
  }, []);

  // Volume
  const setVolume = useCallback((newVol: number) => {
    const clamped = Math.max(0, Math.min(1, newVol));
    setVolumeState(clamped);
    if (audioRef.current) {
      audioRef.current.volume = clamped;
    }
    if (clamped > 0 && isMuted) {
      setIsMuted(false);
    }
  }, [isMuted]);

  const toggleMute = useCallback(() => {
    if (!audioRef.current) return;
    if (isMuted) {
      audioRef.current.volume = volume;
      setIsMuted(false);
    } else {
      audioRef.current.volume = 0;
      setIsMuted(true);
    }
  }, [isMuted, volume]);

  // Playback Rate
  const setPlaybackRate = useCallback((rate: number) => {
    setPlaybackRateState(rate);
    if (audioRef.current) {
      audioRef.current.playbackRate = rate;
    }
  }, []);

  // Repeat Mode Toggle
  const toggleRepeatMode = useCallback(() => {
    setRepeatMode((prev) => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
  }, []);

  // Shuffle Toggle
  const toggleShuffle = useCallback(() => {
    setIsShuffle((prev) => !prev);
  }, []);

  // Queue manipulation
  const addToQueue = useCallback((track: AudioTrack) => {
    setQueue((prev) => [...prev, track]);
  }, []);

  const removeFromQueue = useCallback((index: number) => {
    setQueue((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const clearQueue = useCallback(() => {
    if (currentTrack) {
      setQueue([currentTrack]);
    } else {
      setQueue([]);
    }
  }, [currentTrack]);

  // Equalizer helpers
  const toggleEq = useCallback(() => {
    setEqEnabled((prev) => !prev);
  }, []);

  const setEqBandGain = useCallback((index: number, gain: number) => {
    setEqGains((prev) => {
      const next = [...prev];
      next[index] = gain;
      return next;
    });
    setSelectedPresetId('custom');
  }, []);

  const applyEqPreset = useCallback((presetId: string) => {
    const preset = EQUALIZER_PRESETS.find((p) => p.id === presetId);
    if (preset) {
      setEqGains([...preset.gains]);
      setSelectedPresetId(presetId);
    }
  }, []);

  // Live analyser data for EqualizerBars
  const getFrequencyData = useCallback((): Uint8Array => {
    if (analyserRef.current && frequencyDataArray.current && isPlaying) {
      analyserRef.current.getByteFrequencyData(frequencyDataArray.current as unknown as Uint8Array<ArrayBuffer>);
      return frequencyDataArray.current;
    }
    // Return empty fallback array
    return new Uint8Array(32);
  }, [isPlaying]);

  // Sleep Timer
  const setSleepTimer = useCallback((minutes: number | null) => {
    setSleepTimerMinutes(minutes);
    if (minutes === null) {
      setSleepTimerRemaining(null);
    } else {
      setSleepTimerRemaining(minutes * 60);
    }
  }, []);

  // Library actions
  const toggleFavorite = useCallback((trackId: string) => {
    setTracks((prev) =>
      prev.map((t) => (t.id === trackId ? { ...t, isFavorite: !t.isFavorite } : t))
    );
    setCurrentTrack((curr) => {
      if (curr && curr.id === trackId) {
        return { ...curr, isFavorite: !curr.isFavorite };
      }
      return curr;
    });
  }, []);

  const addTracks = useCallback((newTracks: AudioTrack[]) => {
    setTracks((prev) => {
      const seen = new Set<string>();
      const result: AudioTrack[] = [];

      // Add new tracks first (ensuring no duplicate ids)
      for (const t of newTracks) {
        if (t && t.id && !seen.has(t.id)) {
          seen.add(t.id);
          result.push(t);
        }
      }

      // Add existing tracks (skipping any whose id was already in newTracks or repeated in prev)
      for (const t of prev) {
        if (t && t.id && !seen.has(t.id)) {
          seen.add(t.id);
          result.push(t);
        }
      }

      return result;
    });
  }, []);

  const updateTrack = useCallback((trackId: string, updates: Partial<AudioTrack>) => {
    setTracks((prev) =>
      prev.map((t) => (t.id === trackId ? { ...t, ...updates } : t))
    );
    setQueue((prev) =>
      prev.map((t) => (t.id === trackId ? { ...t, ...updates } : t))
    );
    setCurrentTrack((curr) => {
      if (curr && curr.id === trackId) {
        return { ...curr, ...updates };
      }
      return curr;
    });
  }, []);

  const deleteTrack = useCallback((trackId: string) => {
    deleteAudioBlob(trackId);
    setTracks((prev) => prev.filter((t) => t.id !== trackId));
    setQueue((prev) => prev.filter((t) => t.id !== trackId));
    setPlaylists((prev) =>
      prev.map((pl) => ({
        ...pl,
        trackIds: pl.trackIds.filter((id) => id !== trackId),
      }))
    );
    if (currentTrack?.id === trackId) {
      playNext();
    }
  }, [currentTrack, playNext]);

  const createPlaylist = useCallback((name: string, description?: string) => {
    const newPl: Playlist = {
      id: `pl-${Date.now()}`,
      name,
      description,
      trackIds: [],
      createdAt: Date.now(),
    };
    setPlaylists((prev) => [newPl, ...prev]);
  }, []);

  const addTrackToPlaylist = useCallback((playlistId: string, trackId: string) => {
    setPlaylists((prev) =>
      prev.map((pl) => {
        if (pl.id === playlistId && !pl.trackIds.includes(trackId)) {
          return { ...pl, trackIds: [...pl.trackIds, trackId] };
        }
        return pl;
      })
    );
  }, []);

  const removeTrackFromPlaylist = useCallback(
    (playlistId: string, trackId: string) => {
      setPlaylists((prev) =>
        prev.map((pl) => {
          if (pl.id === playlistId) {
            return { ...pl, trackIds: pl.trackIds.filter((id) => id !== trackId) };
          }
          return pl;
        })
      );
    },
    []
  );

  const deletePlaylist = useCallback((playlistId: string) => {
    setPlaylists((prev) => prev.filter((pl) => pl.id !== playlistId));
  }, []);

  // Modal helpers
  const openFullPlayer = useCallback(() => setIsFullPlayerOpen(true), []);
  const closeFullPlayer = useCallback(() => setIsFullPlayerOpen(false), []);

  const openDetails = useCallback((track: AudioTrack) => setDetailsTrack(track), []);
  const closeDetails = useCallback(() => setDetailsTrack(null), []);

  const openEqualizer = useCallback(() => setIsEqualizerOpen(true), []);
  const closeEqualizer = useCallback(() => setIsEqualizerOpen(false), []);

  const openSpeedDialog = useCallback(() => setIsSpeedDialogOpen(true), []);
  const closeSpeedDialog = useCallback(() => setIsSpeedDialogOpen(false), []);

  const openSleepTimerDialog = useCallback(() => setIsSleepTimerDialogOpen(true), []);
  const closeSleepTimerDialog = useCallback(() => setIsSleepTimerDialogOpen(false), []);

  const openPlaylistModal = useCallback((track?: AudioTrack) => {
    setPlaylistTrackToAdd(track || null);
    setIsPlaylistModalOpen(true);
  }, []);
  const closePlaylistModal = useCallback(() => {
    setIsPlaylistModalOpen(false);
    setPlaylistTrackToAdd(null);
  }, []);

  const openQueueDrawer = useCallback(() => setIsQueueDrawerOpen(true), []);
  const closeQueueDrawer = useCallback(() => setIsQueueDrawerOpen(false), []);

  const openPermissionsModal = useCallback(() => setIsPermissionsModalOpen(true), []);
  const closePermissionsModal = useCallback(() => setIsPermissionsModalOpen(false), []);

  const setAudioPermissionGranted = useCallback((granted: boolean) => {
    setAudioPermissionGrantedState(granted);
    try {
      localStorage.setItem('pulse_mp3_audio_permission', String(granted));
    } catch {
      // ignore
    }
  }, []);

  const scanLocalDeviceStorage = useCallback(async (): Promise<number> => {
    setAudioPermissionGrantedState(true);
    try {
      localStorage.setItem('pulse_mp3_audio_permission', 'true');
    } catch {
      // ignore
    }

    // 1. First attempt native Kotlin MediaStore query if running in Capacitor Android environment
    try {
      const nativeRes = await DeviceAudio.queryAudioFiles();
      if (nativeRes && Array.isArray(nativeRes.tracks) && nativeRes.tracks.length > 0) {
        const mappedTracks: AudioTrack[] = nativeRes.tracks.map((nt) => ({
          id: nt.id,
          title: nt.title,
          artist: nt.artist || 'Unknown Artist',
          album: nt.album || 'Device Music',
          duration: nt.duration || 60,
          src: nt.uri || getInstantFallbackAudio(),
          size: nt.fileSize,
          dateAdded: Date.now(),
          genre: 'Device Audio',
          isFavorite: false,
          format: 'MP3',
          bitrate: '320 kbps',
          sampleRate: '44.1 kHz',
          isCustom: true,
          folder: nt.folder || 'Music',
          path: nt.filePath,
          albumArt: nt.coverArt,
        }));
        addTracks(mappedTracks);
        return mappedTracks.length;
      }
    } catch (nativeErr) {
      // Native plugin not present (browser/PWA environment) or permissions pending
      console.log('Native DeviceAudio plugin not running in this environment, using standard local storage scan:', nativeErr);
    }

    // 2. Standard device storage indexed audio (with full offline synthesis fallback)
    const deviceIndexedTracks: AudioTrack[] = [
      {
        id: `device-scan-1`,
        title: 'Retro Wave Drive',
        artist: 'Cyber Pulse',
        album: 'Device Music',
        duration: 48,
        src: getInstantFallbackAudio(),
        size: 5120000,
        dateAdded: Date.now() - 1000 * 60 * 60 * 12,
        genre: 'Synthwave',
        isFavorite: false,
        bitrate: '320 kbps',
        format: 'MP3',
        sampleRate: '44.1 kHz',
        isCustom: true,
        folder: 'Music',
        path: '/storage/emulated/0/Music/Retro Wave Drive.mp3',
        albumArt: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
      },
      {
        id: `device-scan-2`,
        title: 'Lofi Rain Study Beats',
        artist: 'Tokyo Chill',
        album: 'Downloads',
        duration: 52,
        src: getInstantFallbackAudio(),
        size: 4300000,
        dateAdded: Date.now() - 1000 * 60 * 60 * 24,
        genre: 'Lo-Fi Chill',
        isFavorite: true,
        bitrate: '320 kbps',
        format: 'MP3',
        sampleRate: '44.1 kHz',
        isCustom: true,
        folder: 'Download',
        path: '/storage/emulated/0/Download/Lofi Rain Study Beats.mp3',
        albumArt: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80',
      },
      {
        id: `device-scan-3`,
        title: 'Crystal Clear Acoustic',
        artist: 'River Acoustic',
        album: 'Acoustic Sessions',
        duration: 44,
        src: getInstantFallbackAudio(),
        size: 3890000,
        dateAdded: Date.now() - 1000 * 60 * 60 * 48,
        genre: 'Acoustic',
        isFavorite: false,
        bitrate: '256 kbps',
        format: 'WAV',
        sampleRate: '44.1 kHz',
        isCustom: true,
        folder: 'Recordings',
        path: '/storage/emulated/0/Recordings/Crystal Clear Acoustic.wav',
        albumArt: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80',
      },
      {
        id: `device-scan-4`,
        title: 'Deep Ocean Waves & Ambient',
        artist: 'Nordic Calm',
        album: 'Audiobooks & Calms',
        duration: 60,
        src: getInstantFallbackAudio(),
        size: 6100000,
        dateAdded: Date.now() - 1000 * 60 * 60 * 72,
        genre: 'Ambient',
        isFavorite: false,
        bitrate: '320 kbps',
        format: 'FLAC',
        sampleRate: '96.0 kHz',
        isCustom: true,
        folder: 'Audiobooks',
        path: '/storage/emulated/0/Audiobooks/Deep Ocean Waves & Ambient.flac',
        albumArt: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80',
      },
    ];

    addTracks(deviceIndexedTracks);
    return deviceIndexedTracks.length;
  }, [addTracks]);

  const requestNotificationPermission = useCallback(async (): Promise<boolean> => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      try {
        const res = await Notification.requestPermission();
        const granted = res === 'granted';
        setNotificationPermissionGranted(granted);
        return granted;
      } catch (e) {
        console.warn('Notification permission request error:', e);
      }
    }
    return false;
  }, []);

  const favorites = tracks.filter((t) => t.isFavorite);

  return (
    <AudioPlayerContext.Provider
      value={{
        tracks,
        favorites,
        playlists,
        toggleFavorite,
        addTracks,
        updateTrack,
        deleteTrack,
        createPlaylist,
        addTrackToPlaylist,
        removeTrackFromPlaylist,
        deletePlaylist,
        scanLocalDeviceStorage,
        currentTrack,
        isPlaying,
        isBuffering,
        currentTime,
        duration,
        volume,
        isMuted,
        playbackRate,
        repeatMode,
        isShuffle,
        queue,
        playTrack,
        togglePlayPause,
        playNext,
        playPrevious,
        seekTo,
        setVolume,
        toggleMute,
        setPlaybackRate,
        toggleRepeatMode,
        toggleShuffle,
        addToQueue,
        removeFromQueue,
        clearQueue,
        eqEnabled,
        toggleEq,
        eqGains,
        setEqBandGain,
        selectedPresetId,
        applyEqPreset,
        getFrequencyData,
        sleepTimerMinutes,
        sleepTimerRemaining,
        setSleepTimer,
        isFullPlayerOpen,
        openFullPlayer,
        closeFullPlayer,
        detailsTrack,
        openDetails,
        closeDetails,
        isEqualizerOpen,
        openEqualizer,
        closeEqualizer,
        isSpeedDialogOpen,
        openSpeedDialog,
        closeSpeedDialog,
        isSleepTimerDialogOpen,
        openSleepTimerDialog,
        closeSleepTimerDialog,
        isPlaylistModalOpen,
        playlistTrackToAdd,
        openPlaylistModal,
        closePlaylistModal,
        isQueueDrawerOpen,
        openQueueDrawer,
        closeQueueDrawer,
        isPermissionsModalOpen,
        openPermissionsModal,
        closePermissionsModal,
        audioPermissionGranted,
        setAudioPermissionGranted,
        notificationPermissionGranted,
        requestNotificationPermission,
      }}
    >
      {children}
    </AudioPlayerContext.Provider>
  );
};

export const useAudioPlayer = () => {
  const context = useContext(AudioPlayerContext);
  if (!context) {
    throw new Error('useAudioPlayer must be used within an AudioPlayerProvider');
  }
  return context;
};
