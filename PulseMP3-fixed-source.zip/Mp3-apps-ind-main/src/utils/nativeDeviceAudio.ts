import { registerPlugin } from '@capacitor/core';

export interface DeviceAudioTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  duration: number; // in seconds
  fileSize: number;
  uri: string;
  filePath: string;
  coverArt?: string;
  folder?: string;
}

export interface DeviceAudioQueryResult {
  tracks: DeviceAudioTrack[];
  count: number;
  platform: string;
}

export interface PlayDeviceAudioOptions {
  uri?: string;
  filePath?: string;
}

export interface PlayDeviceAudioResult {
  success: boolean;
  duration?: number;
  isPlaying?: boolean;
}

export interface DeviceAudioPlaybackState {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  currentUri: string;
}

export interface DeviceAudioPlugin {
  queryAudioFiles(): Promise<DeviceAudioQueryResult>;
  playDeviceAudio(options: PlayDeviceAudioOptions): Promise<PlayDeviceAudioResult>;
  pauseDeviceAudio(): Promise<{ success: boolean; isPlaying: boolean }>;
  resumeDeviceAudio(): Promise<{ success: boolean; isPlaying: boolean }>;
  seekDeviceAudio(options: { position: number }): Promise<{ success: boolean; position: number }>;
  getDeviceAudioPlaybackState(): Promise<DeviceAudioPlaybackState>;
}

export const DeviceAudio = registerPlugin<DeviceAudioPlugin>('DeviceAudio');
