
/**
 * PulseMP3 audio metadata helper.
 * Extracts ID3v2/ID3v1 title, artist, album, genre and embedded cover art.
 * Persists audio blobs in IndexedDB for offline playback.
 */

export const DEFAULT_ALBUM_ARTS = [
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1465847899084-d164df4dedc6?w=600&auto=format&fit=crop&q=80",
  "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=600&auto=format&fit=crop&q=80",
];

export function getDeterministicCover(name: string): string {
  let hash = 0;

  for (let i = 0; i < name.length; i++) {
    hash = (name.charCodeAt(i) + ((hash << 5) - hash)) | 0;
  }

  return DEFAULT_ALBUM_ARTS[
    (Math.abs(hash) % DEFAULT_ALBUM_ARTS.length)
  ];
}

export function getAudioDuration(file: Blob): Promise<number> {
  return new Promise((resolve) => {
    if (typeof document === "undefined" || typeof URL === "undefined") {
      resolve(0);
      return;
    }

    let url: string | null = null;
    let audio: HTMLAudioElement | null = null;
    let finished = false;

    const finish = (duration: number) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);

      if (audio) {
        audio.onloadedmetadata = null;
        audio.onerror = null;
        audio.removeAttribute("src");
        audio.load();
      }

      if (url) URL.revokeObjectURL(url);
      resolve(duration);
    };

    const timer = setTimeout(() => finish(0), 10000);

    try {
      audio = document.createElement("audio");
      audio.preload = "metadata";
      url = URL.createObjectURL(file);

      audio.onloadedmetadata = () => {
        const duration = audio?.duration ?? 0;
        finish(Number.isFinite(duration) && duration > 0
          ? Math.round(duration)
          : 0);
      };

      audio.onerror = () => finish(0);
      audio.src = url;
    } catch {
      finish(0);
    }
  });
}

function decodeID3Text(
  buffer: ArrayBuffer,
  encodingByte: number
): string {
  try {
    const encodings: Record<number, string> = {
      0: "iso-8859-1",
      1: "utf-16",
      2: "utf-16be",
      3: "utf-8",
    };

    const decoder = new TextDecoder(encodings[encodingByte] || "utf-8");
    return decoder
      .decode(buffer)
      .replace(/\0/g, "")
      .trim();
  } catch {
    return "";
  }
}

function decodeTextFrame(
  buffer: ArrayBuffer,
  offset: number,
  length: number
): string {
  if (length < 1 || offset < 0 || offset + length > buffer.byteLength) {
    return "";
  }

  const encoding = new DataView(buffer).getUint8(offset);
  return decodeID3Text(buffer.slice(offset + 1, offset + length), encoding);
}

function syncSafeInteger(view: DataView, offset: number): number {
  return (
    ((view.getUint8(offset) & 0x7f) << 21) |
    ((view.getUint8(offset + 1) & 0x7f) << 14) |
    ((view.getUint8(offset + 2) & 0x7f) << 7) |
    (view.getUint8(offset + 3) & 0x7f)
  );
}

function bytesToDataUrl(bytes: Uint8Array, mimeType: string): string {
  // Chunk the conversion to avoid overflowing the argument stack.
  const chunkSize = 0x8000;
  let binary = "";

  for (let i = 0; i < bytes.length; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, bytes.length));
    binary += String.fromCharCode(...chunk);
  }

  return `data:${mimeType};base64,${btoa(binary)}`;
}

function getNullTerminator(
  view: DataView,
  start: number,
  end: number,
  encoding: number
): number {
  const step = encoding === 1 || encoding === 2 ? 2 : 1;

  for (let i = start; i + step <= end; i += step) {
    if (view.getUint8(i) === 0 &&
        (step === 1 || view.getUint8(i + 1) === 0)) {
      return i + step;
    }
  }

  return end;
}

function extractPicture(
  buffer: ArrayBuffer,
  offset: number,
  length: number
): string | undefined {
  const end = offset + length;

  if (length < 5 || offset < 0 || end > buffer.byteLength) {
    return undefined;
  }

  const view = new DataView(buffer);
  const encoding = view.getUint8(offset);
  let cursor = offset + 1;

  // MIME type is a null-terminated ISO-8859-1 string.
  const mimeStart = cursor;

  while (cursor < end && view.getUint8(cursor) !== 0) {
    cursor++;
  }

  if (cursor >= end) return undefined;

  let mimeType = "";
  for (let i = mimeStart; i < cursor; i++) {
    mimeType += String.fromCharCode(view.getUint8(i));
  }

  cursor++; // MIME terminator
  cursor++; // Picture type byte

  // Skip the image description using its declared text encoding.
  cursor = getNullTerminator(view, cursor, end, encoding);

  if (cursor >= end) return undefined;

  const imageBytes = new Uint8Array(buffer.slice(cursor, end));

  if (imageBytes.length < 100) return undefined;

  // Do not trust arbitrary MIME strings for a data URL.
  if (!/^image\/[a-zA-Z0-9.+-]+$/.test(mimeType)) {
    mimeType = "image/jpeg";
  }

  return bytesToDataUrl(imageBytes, mimeType);
}

export interface ParsedAudioMetadata {
  title: string;
  artist: string;
  album: string;
  duration: number;
  albumArt?: string;
  genre?: string;
}

export async function extractAudioMetadata(
  file: File
): Promise<ParsedAudioMetadata> {
  let title = "";
  let artist = "";
  let album = "";
  let genre = "";
  let albumArt: string | undefined;

  // Read the ID3 header first, then read the complete tag when reasonable.
  try {
    if (file.size >= 10) {
      const header = await file.slice(0, 10).arrayBuffer();
      const headerView = new DataView(header);

      const isID3 =
        headerView.getUint8(0) === 0x49 &&
        headerView.getUint8(1) === 0x44 &&
        headerView.getUint8(2) === 0x33;

      if (isID3) {
        const version = headerView.getUint8(3);
        const flags = headerView.getUint8(5);
        const tagSize = syncSafeInteger(headerView, 6);

        // Avoid loading a malformed or enormous tag into memory.
        const maxTagBytes = 16 * 1024 * 1024;

        if (
          version >= 2 &&
          version <= 4 &&
          tagSize > 0 &&
          tagSize <= maxTagBytes &&
          tagSize + 10 <= file.size
        ) {
          const buffer = await file.slice(0, tagSize + 10).arrayBuffer();
          const view = new DataView(buffer);
          let offset = 10;
          const end = Math.min(tagSize + 10, buffer.byteLength);

          // Extended header: ID3v2.3 uses a regular integer;
          // ID3v2.4 uses a sync-safe integer.
          if (flags & 0x40) {
            if (offset + 4 > end) {
              offset = end;
            } else {
              const extendedSize = version === 4
                ? syncSafeInteger(view, offset)
                : view.getUint32(offset, false);

              offset += version === 4
                ? extendedSize
                : extendedSize + 4;
            }
          }

          while (offset + 10 <= end) {
            const frameId = String.fromCharCode(
              view.getUint8(offset),
              view.getUint8(offset + 1),
              view.getUint8(offset + 2),
              view.getUint8(offset + 3)
            );

            if (frameId === "\0\0\0\0") break;
            if (!/^[A-Z0-9]{4}$/.test(frameId)) break;

            const frameSize = version === 4
              ? syncSafeInteger(view, offset + 4)
              : view.getUint32(offset + 4, false);

            if (frameSize <= 0 || offset + 10 + frameSize > end) break;

            const dataOffset = offset + 10;
            const frameFlags = view.getUint8(offset + 9);

            // Skip compressed/encrypted frames that this parser cannot decode.
            const compressedOrEncrypted = version === 3
              ? (frameFlags & 0xc0) !== 0
              : (frameFlags & 0x0c) !== 0;

            if (!compressedOrEncrypted) {
              if (frameId === "TIT2" && !title) {
                title = decodeTextFrame(buffer, dataOffset, frameSize);
              } else if (frameId === "TPE1" && !artist) {
                artist = decodeTextFrame(buffer, dataOffset, frameSize);
              } else if (frameId === "TALB" && !album) {
                album = decodeTextFrame(buffer, dataOffset, frameSize);
              } else if (frameId === "TCON" && !genre) {
                genre = decodeTextFrame(buffer, dataOffset, frameSize);
              } else if (frameId === "APIC" && !albumArt) {
                albumArt = extractPicture(buffer, dataOffset, frameSize);
              }
            }

            offset += 10 + frameSize;
          }
        }
      }
    }
  } catch (error) {
    console.debug("ID3v2 metadata parsing notice:", error);
  }

  // ID3v1 fallback.
  if ((!title || !artist || !album || !genre) && file.size >= 128) {
    try {
      const tail = await file.slice(file.size - 128).arrayBuffer();
      const view = new DataView(tail);

      if (
        view.getUint8(0) === 0x54 &&
        view.getUint8(1) === 0x41 &&
        view.getUint8(2) === 0x47
      ) {
        const decoder = new TextDecoder("iso-8859-1");
        const readField = (start: number, end: number) =>
          decoder.decode(tail.slice(start, end))
            .replace(/\0/g, "")
            .trim();

        if (!title) title = readField(3, 33);
        if (!artist) artist = readField(33, 63);
        if (!album) album = readField(63, 93);
        if (!genre) {
          const genreIndex = view.getUint8(127);
          if (genreIndex !== 255) genre = `Genre ${genreIndex}`;
        }
      }
    } catch {
      // Ignore missing or malformed ID3v1 tags.
    }
  }

  // Use filename only when the audio tags do not provide a title.
  const cleanName = file.name
    .replace(/\.[^/.]+$/, "")
    .replace(/_/g, " ")
    .trim();

  if (!title) {
    const parts = cleanName.split(" - ");

    if (parts.length >= 2) {
      const first = parts[0].replace(/^\d+\s*/, "").trim();
      title = parts.slice(1).join(" - ").trim();

      if (!artist) artist = first;
    } else {
      title = cleanName.replace(/^\d+[\s._-]*/, "").trim();
    }
  }

  title = title || "Unknown Track";
  artist = artist || "Unknown Artist";
  album = album || "Unknown Album";
  genre = genre || "MP3 Audio";

  if (!albumArt) {
    albumArt = getDeterministicCover(title);
  }

  const duration = await getAudioDuration(file);

  return {
    title,
    artist,
    album,
    duration,
    albumArt,
    genre,
  };
}

/**
 * Backward-compatible embedded cover art extractor.
 * Returns a data URL for embedded art or the default cover.
 */
export async function extractEmbeddedCoverArt(
  file: File
): Promise<string | null> {
  const metadata = await extractAudioMetadata(file);
  return metadata.albumArt || null;
}

// IndexedDB persistence. Keep these names stable to preserve existing data.
const DB_NAME = "PulseMP3_AudioStorage";
const STORE_NAME = "audio_blobs";

function openAudioDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === "undefined" || !window.indexedDB) {
      reject(new Error("IndexedDB not supported"));
      return;
    }

    const request = window.indexedDB.open(DB_NAME, 1);

    request.onupgradeneeded = () => {
      const db = request.result;

      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function storeAudioBlob(
  id: string,
  file: Blob
): Promise<void> {
  let db: IDBDatabase | undefined;

  try {
    db = await openAudioDB();

    await new Promise<void>((resolve, reject) => {
      const tx = db!.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(file, id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error("Storage transaction aborted"));
    });
  } catch (error) {
    console.warn("Could not store audio blob in IndexedDB:", error);
  } finally {
    db?.close();
  }
}

export async function getAudioBlob(id: string): Promise<Blob | null> {
  let db: IDBDatabase | undefined;

  try {
    db = await openAudioDB();

    return await new Promise<Blob | null>((resolve) => {
      const tx = db!.transaction(STORE_NAME, "readonly");
      const request = tx.objectStore(STORE_NAME).get(id);

      request.onsuccess = () => resolve(request.result ?? null);
      request.onerror = () => resolve(null);
    });
  } catch {
    return null;
  } finally {
    db?.close();
  }
}

export async function deleteAudioBlob(id: string): Promise<void> {
  let db: IDBDatabase | undefined;

  try {
    db = await openAudioDB();

    await new Promise<void>((resolve, reject) => {
      const tx = db!.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error("Delete transaction aborted"));
    });
  } catch (error) {
    console.warn("Could not delete audio blob:", error);
  } finally {
    db?.close();
  }
}
