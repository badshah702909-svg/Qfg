/**
 * Audio synthesis helper that generates realistic, rhythmic musical audio tracks
 * as playable WAV Blobs using Web Audio OfflineAudioContext.
 * This guarantees 100% offline, self-contained playback with genuine audio frequencies
 * for live equalizer visualization and speaker output.
 */

// Simple WAV header generator for an AudioBuffer
export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numChannels = buffer.numberOfChannels;
  const sampleRate = buffer.sampleRate;
  const format = 1; // PCM
  const bitDepth = 16;

  const numSamples = buffer.length * numChannels;
  const bytesPerSample = bitDepth / 8;
  const blockAlign = numChannels * bytesPerSample;
  const dataByteLength = numSamples * bytesPerSample;
  const arrayBuffer = new ArrayBuffer(44 + dataByteLength);
  const view = new DataView(arrayBuffer);

  // RIFF identifier
  writeString(view, 0, 'RIFF');
  // file length minus RIFF identifier & length
  view.setUint32(4, 36 + dataByteLength, true);
  // RIFF type
  writeString(view, 8, 'WAVE');
  // format chunk identifier
  writeString(view, 12, 'fmt ');
  // format chunk length
  view.setUint32(16, 16, true);
  // sample format (raw)
  view.setUint16(20, format, true);
  // channel count
  view.setUint16(22, numChannels, true);
  // sample rate
  view.setUint32(24, sampleRate, true);
  // byte rate (sample rate * block align)
  view.setUint32(28, sampleRate * blockAlign, true);
  // block align
  view.setUint16(32, blockAlign, true);
  // bits per sample
  view.setUint16(34, bitDepth, true);
  // data chunk identifier
  writeString(view, 36, 'data');
  // data chunk length
  view.setUint32(40, dataByteLength, true);

  // Write audio samples
  let offset = 44;
  const channelData: Float32Array[] = [];
  for (let i = 0; i < numChannels; i++) {
    channelData.push(buffer.getChannelData(i));
  }

  for (let i = 0; i < buffer.length; i++) {
    for (let channel = 0; channel < numChannels; channel++) {
      let sample = channelData[channel][i];
      // Clamp between -1 and 1
      sample = Math.max(-1, Math.min(1, sample));
      // Convert to 16-bit signed integer
      const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
      view.setInt16(offset, intSample, true);
      offset += 2;
    }
  }

  return new Blob([arrayBuffer], { type: 'audio/wav' });
}

function writeString(view: DataView, offset: number, string: string) {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}

// In-memory cache for synthesized audio URLs so they generate once and play instantly
const themeAudioCache = new Map<string, string>();

// Fast immediate fallback audio WAV blob in case of offline/media decode failure or unindexed storage MP3s
export function getInstantFallbackAudio(seed: string = 'default'): string {
  const cacheKey = `instant_fallback_${seed}`;
  if (themeAudioCache.has(cacheKey)) {
    return themeAudioCache.get(cacheKey)!;
  }
  const sampleRate = 22050;
  const durationSec = 14; // 14 seconds rich musical loop
  const numSamples = Math.floor(sampleRate * durationSec);
  const arrayBuffer = new ArrayBuffer(44 + numSamples * 2);
  const view = new DataView(arrayBuffer);

  writeString(view, 0, 'RIFF');
  view.setUint32(4, 36 + numSamples * 2, true);
  writeString(view, 8, 'WAVE');
  writeString(view, 12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // Mono
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeString(view, 36, 'data');
  view.setUint32(40, numSamples * 2, true);

  // Musical chord frequencies (Am - F - C - G progression)
  const progressions = [
    [220.0, 261.63, 329.63, 110.0], // A minor
    [174.61, 220.0, 261.63, 87.31], // F major
    [130.81, 164.81, 196.0, 130.81], // C major
    [196.0, 246.94, 293.66, 98.0], // G major
  ];

  let offset = 44;
  for (let i = 0; i < numSamples; i++) {
    const t = i / sampleRate;
    const chordIdx = Math.floor((t / 3.5) % 4);
    const chord = progressions[chordIdx];

    // Chords + melody
    const s1 = Math.sin(2 * Math.PI * chord[0] * t);
    const s2 = Math.sin(2 * Math.PI * chord[1] * t) * 0.7;
    const s3 = Math.sin(2 * Math.PI * chord[2] * t) * 0.6;
    const bass = Math.sin(2 * Math.PI * chord[3] * t) * 0.5;

    // Rhythmic pulse / beat (120 bpm)
    const beatPhase = (t * 2) % 1;
    const kick = Math.sin(2 * Math.PI * 55 * Math.max(0, 0.15 - beatPhase)) * 0.4;
    const tremolo = 0.8 + 0.2 * Math.sin(2 * Math.PI * 4 * t);

    // Subtle fade in and out at loop edges
    const envelope = Math.min(1, Math.min(t * 3, (durationSec - t) * 3));

    const sample = Math.max(
      -1,
      Math.min(1, ((s1 + s2 + s3 + bass) * 0.22 * tremolo + kick) * envelope)
    );
    const intSample = sample < 0 ? sample * 0x8000 : sample * 0x7fff;
    view.setInt16(offset, intSample, true);
    offset += 2;
  }

  const blob = new Blob([arrayBuffer], { type: 'audio/wav' });
  const url = URL.createObjectURL(blob);
  themeAudioCache.set(cacheKey, url);
  if (!themeAudioCache.has('instant_fallback_default')) {
    themeAudioCache.set('instant_fallback_default', url);
  }
  return url;
}

// Generate realistic music tracks with melody, chords, bass and drums
export async function generateDemoTrack(
  theme: 'lofi' | 'synthwave' | 'acoustic' | 'ambient' | 'electronic',
  durationSec: number = 24
): Promise<string> {
  const cacheKey = `${theme}_${durationSec}`;
  if (themeAudioCache.has(cacheKey)) {
    return themeAudioCache.get(cacheKey)!;
  }

  const effectiveDuration = Math.min(24, Math.max(12, durationSec));
  const sampleRate = 32000; // Fast rendering sample rate
  const totalSamples = Math.floor(sampleRate * effectiveDuration);
  const offlineCtx = new OfflineAudioContext(2, totalSamples, sampleRate);

  const tempoMap = {
    lofi: 82,
    synthwave: 118,
    acoustic: 95,
    ambient: 68,
    electronic: 124,
  };

  const bpm = tempoMap[theme] || 100;
  const beatDuration = 60 / bpm;
  const totalBeats = Math.floor(durationSec / beatDuration);

  // Scales in Hz
  const scales = {
    lofi: [220, 261.63, 293.66, 329.63, 392.0, 440, 523.25], // A minor pentatonic / blues
    synthwave: [146.83, 174.61, 196.0, 220.0, 261.63, 293.66, 349.23, 392.0], // D minor
    acoustic: [196.0, 246.94, 293.66, 329.63, 392.0, 493.88, 587.33], // G major
    ambient: [130.81, 164.81, 196.0, 246.94, 293.66, 392.0], // C maj9
    electronic: [130.81, 155.56, 174.61, 196.0, 233.08, 261.63], // C minor
  };

  const currentScale = scales[theme] || scales.lofi;

  // Master compression / gain
  const masterGain = offlineCtx.createGain();
  masterGain.gain.setValueAtTime(0.75, 0);
  masterGain.connect(offlineCtx.destination);

  // Reverb simulation via simple delay and feedback
  const delay = offlineCtx.createDelay();
  delay.delayTime.setValueAtTime(beatDuration * 0.75, 0);
  const delayFeedback = offlineCtx.createGain();
  delayFeedback.gain.setValueAtTime(0.3, 0);
  delay.connect(delayFeedback);
  delayFeedback.connect(delay);
  delay.connect(masterGain);

  // 1. Kick & Percussion (for rhythmic themes)
  if (theme !== 'ambient') {
    for (let beat = 0; beat < totalBeats; beat++) {
      const time = beat * beatDuration;
      if (time >= durationSec - 1) break;

      // Kick on 0, 2 or four-on-the-floor for electronic/synthwave
      const isKick =
        theme === 'electronic' || theme === 'synthwave'
          ? beat % 1 === 0
          : beat % 2 === 0;

      if (isKick) {
        const osc = offlineCtx.createOscillator();
        const gain = offlineCtx.createGain();
        osc.frequency.setValueAtTime(140, time);
        osc.frequency.exponentialRampToValueAtTime(38, time + 0.12);
        gain.gain.setValueAtTime(0.7, time);
        gain.gain.exponentialRampToValueAtTime(0.001, time + 0.18);
        osc.connect(gain);
        gain.connect(masterGain);
        osc.start(time);
        osc.stop(time + 0.2);
      }

      // Snare / Clack on beats 1, 3
      if (beat % 2 === 1) {
        const snareNoise = offlineCtx.createOscillator();
        snareNoise.type = 'triangle';
        const snareGain = offlineCtx.createGain();
        snareNoise.frequency.setValueAtTime(220, time);
        snareNoise.frequency.exponentialRampToValueAtTime(80, time + 0.1);
        snareGain.gain.setValueAtTime(0.35, time);
        snareGain.gain.exponentialRampToValueAtTime(0.001, time + 0.15);
        snareNoise.connect(snareGain);
        snareGain.connect(masterGain);
        snareNoise.start(time);
        snareNoise.stop(time + 0.2);
      }

      // Hi-hat on eighth notes
      for (let sub = 0; sub < 2; sub++) {
        const hatTime = time + sub * (beatDuration / 2);
        const osc = offlineCtx.createOscillator();
        osc.type = 'square';
        const gain = offlineCtx.createGain();
        const filter = offlineCtx.createBiquadFilter();
        filter.type = 'highpass';
        filter.frequency.setValueAtTime(7000, hatTime);

        osc.frequency.setValueAtTime(1000 + (beat % 4) * 300, hatTime);
        gain.gain.setValueAtTime(sub === 0 ? 0.08 : 0.04, hatTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, hatTime + 0.05);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(masterGain);
        osc.start(hatTime);
        osc.stop(hatTime + 0.06);
      }
    }
  }

  // 2. Bassline
  const bassScale = currentScale.map((f) => f / 2);
  for (let beat = 0; beat < totalBeats; beat += 2) {
    const time = beat * beatDuration;
    if (time >= durationSec - 1) break;

    const note = bassScale[(beat / 2) % bassScale.length];
    const osc = offlineCtx.createOscillator();
    osc.type = theme === 'synthwave' ? 'sawtooth' : 'sine';
    const gain = offlineCtx.createGain();

    const filter = offlineCtx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(350, time);

    osc.frequency.setValueAtTime(note, time);
    gain.gain.setValueAtTime(0.35, time);
    gain.gain.exponentialRampToValueAtTime(0.001, time + beatDuration * 1.8);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(masterGain);

    osc.start(time);
    osc.stop(time + beatDuration * 1.9);
  }

  // 3. Chords / Arpeggios / Melody
  const chordProgression = [
    [currentScale[0], currentScale[2], currentScale[4]],
    [currentScale[3], currentScale[5], currentScale[1]],
    [currentScale[4], currentScale[6] || currentScale[0], currentScale[2]],
    [currentScale[1], currentScale[3], currentScale[5]],
  ];

  for (let bar = 0; bar < Math.floor(totalBeats / 4); bar++) {
    const barTime = bar * 4 * beatDuration;
    const chord = chordProgression[bar % chordProgression.length];

    // Pad / Sustained Chords
    chord.forEach((freq, idx) => {
      const osc = offlineCtx.createOscillator();
      osc.type = theme === 'synthwave' ? 'sawtooth' : theme === 'ambient' ? 'sine' : 'triangle';
      const gain = offlineCtx.createGain();

      const filter = offlineCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(800 + idx * 200, barTime);

      osc.frequency.setValueAtTime(freq, barTime);
      gain.gain.setValueAtTime(0.001, barTime);
      gain.gain.linearRampToValueAtTime(0.12, barTime + 0.4);
      gain.gain.exponentialRampToValueAtTime(0.001, barTime + beatDuration * 3.8);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(masterGain);
      gain.connect(delay);

      osc.start(barTime);
      osc.stop(barTime + beatDuration * 4);
    });

    // Melodic Arpeggio / Lead
    for (let step = 0; step < 8; step++) {
      const noteTime = barTime + step * (beatDuration / 2);
      if (noteTime >= durationSec - 1) break;

      const melNote =
        currentScale[(step * 2 + bar) % currentScale.length] *
        (step % 3 === 0 ? 2 : 1);

      const osc = offlineCtx.createOscillator();
      osc.type = theme === 'lofi' ? 'sine' : 'triangle';
      const gain = offlineCtx.createGain();

      osc.frequency.setValueAtTime(melNote, noteTime);
      gain.gain.setValueAtTime(0.1, noteTime);
      gain.gain.exponentialRampToValueAtTime(0.001, noteTime + beatDuration * 0.45);

      osc.connect(gain);
      gain.connect(masterGain);
      gain.connect(delay);

      osc.start(noteTime);
      osc.stop(noteTime + beatDuration * 0.5);
    }
  }

  // Render to buffer
  const renderedBuffer = await offlineCtx.startRendering();
  const wavBlob = audioBufferToWav(renderedBuffer);
  const resultUrl = URL.createObjectURL(wavBlob);
  themeAudioCache.set(cacheKey, resultUrl);
  themeAudioCache.set(theme, resultUrl);
  return resultUrl;
}

// Format duration helper (mm:ss)
export function formatTime(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

// Format bytes into readable string
export function formatBytes(bytes?: number): string {
  if (!bytes || isNaN(bytes)) return '3.8 MB';
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  if (bytes === 0) return '0 Byte';
  const i = Math.floor(Math.log(bytes) / Math.log(1024));
  return `${(bytes / Math.pow(1024, i)).toFixed(1)} ${sizes[i]}`;
}
