package com.example.mp3player

import android.os.Bundle
import com.getcapacitor.BridgeActivity

class MainActivity : BridgeActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        registerPlugin(DeviceAudioPlugin::class.java)
        super.onCreate(savedInstanceState)
    }
}
