package com.example.mp3player

import android.Manifest
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import java.io.ByteArrayOutputStream
import java.io.File
import android.util.Base64

/**
 * Kotlin native Capacitor Plugin for automatic mobile device audio querying via MediaStore
 * and high-performance native playback of local MP3/audio files on Android devices.
 */
@CapacitorPlugin(
    name = "DeviceAudio",
    permissions = [
        Permission(
            alias = "readAudio",
            strings = [
                Manifest.permission.READ_MEDIA_AUDIO,
                Manifest.permission.READ_EXTERNAL_STORAGE
            ]
        )
    ]
)
class DeviceAudioPlugin : Plugin() {

    private var mediaPlayer: MediaPlayer? = null
    private var currentPlayingUri: String? = null

    @PluginMethod
    fun queryAudioFiles(call: PluginCall) {
        val tracksArray = JSArray()

        try {
            val contentResolver = context.contentResolver
            val uri: Uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.ALBUM_ID
            )

            // Select music files only, non-empty duration
            val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} > 1000"
            val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"

            contentResolver.query(uri, projection, selection, null, sortOrder)?.use { cursor ->
                val idColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                val albumColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                val durationColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val dataColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                val sizeColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val albumIdColumn = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idColumn)
                    val title = cursor.getString(titleColumn) ?: "Unknown Track"
                    val artist = cursor.getString(artistColumn) ?: "Unknown Artist"
                    val album = cursor.getString(albumColumn) ?: "Unknown Album"
                    val durationMs = cursor.getLong(durationColumn)
                    val path = cursor.getString(dataColumn) ?: ""
                    val sizeBytes = cursor.getLong(sizeColumn)
                    val albumId = cursor.getLong(albumIdColumn)

                    val contentUri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val albumArtUri = getAlbumArtDataUri(albumId)

                    val trackObj = JSObject().apply {
                        put("id", "android-native-$id")
                        put("title", title)
                        put("artist", artist)
                        put("album", album)
                        put("duration", (durationMs / 1000.0))
                        put("fileSize", sizeBytes)
                        put("uri", contentUri.toString())
                        put("filePath", path)
                        put("coverArt", albumArtUri ?: "")
                        put("folder", extractFolderName(path))
                    }
                    tracksArray.put(trackObj)
                }
            }

            val ret = JSObject()
            ret.put("tracks", tracksArray)
            ret.put("count", tracksArray.length())
            ret.put("platform", "Android Kotlin")
            call.resolve(ret)

        } catch (e: Exception) {
            val errorRet = JSObject()
            errorRet.put("error", e.localizedMessage ?: "Failed to read device audio")
            errorRet.put("tracks", tracksArray)
            call.reject("MediaStore query failed", e)
        }
    }

    /**
     * Play native device audio file directly through Android MediaPlayer
     * Supporting content:// URIs and absolute file paths (/storage/emulated/0/...)
     */
    @PluginMethod
    fun playDeviceAudio(call: PluginCall) {
        val uriString = call.getString("uri")
        val filePath = call.getString("filePath")

        if (uriString.isNullOrEmpty() && filePath.isNullOrEmpty()) {
            call.reject("Audio URI or file path must be provided")
            return
        }

        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null

            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
            }

            if (!uriString.isNullOrEmpty() && uriString.startsWith("content://")) {
                val parsedUri = Uri.parse(uriString)
                player.setDataSource(context, parsedUri)
                currentPlayingUri = uriString
            } else if (!filePath.isNullOrEmpty() && File(filePath).exists()) {
                player.setDataSource(filePath)
                currentPlayingUri = filePath
            } else if (!uriString.isNullOrEmpty()) {
                player.setDataSource(uriString)
                currentPlayingUri = uriString
            } else {
                call.reject("Specified audio file does not exist")
                return
            }

            player.prepare()
            player.start()
            mediaPlayer = player

            val ret = JSObject().apply {
                put("success", true)
                put("duration", (player.duration / 1000.0))
                put("isPlaying", true)
            }
            call.resolve(ret)

        } catch (e: Exception) {
            call.reject("Error playing audio natively: ${e.message}", e)
        }
    }

    @PluginMethod
    fun pauseDeviceAudio(call: PluginCall) {
        try {
            mediaPlayer?.let {
                if (it.isPlaying) {
                    it.pause()
                }
            }
            val ret = JSObject().apply {
                put("success", true)
                put("isPlaying", false)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to pause audio: ${e.message}", e)
        }
    }

    @PluginMethod
    fun resumeDeviceAudio(call: PluginCall) {
        try {
            mediaPlayer?.let {
                if (!it.isPlaying) {
                    it.start()
                }
            }
            val ret = JSObject().apply {
                put("success", true)
                put("isPlaying", true)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to resume audio: ${e.message}", e)
        }
    }

    @PluginMethod
    fun seekDeviceAudio(call: PluginCall) {
        val positionSeconds = call.getDouble("position") ?: 0.0
        try {
            mediaPlayer?.seekTo((positionSeconds * 1000).toInt())
            val ret = JSObject().apply {
                put("success", true)
                put("position", positionSeconds)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("Failed to seek: ${e.message}", e)
        }
    }

    @PluginMethod
    fun getDeviceAudioPlaybackState(call: PluginCall) {
        val player = mediaPlayer
        val ret = JSObject().apply {
            put("isPlaying", player?.isPlaying ?: false)
            put("currentTime", if (player != null) player.currentPosition / 1000.0 else 0.0)
            put("duration", if (player != null) player.duration / 1000.0 else 0.0)
            put("currentUri", currentPlayingUri ?: "")
        }
        call.resolve(ret)
    }

    /**
     * Return a small WebView-safe artwork data URI instead of a content:// URL.
     * Android WebViews cannot reliably load MediaStore album-art content URIs in img tags.
     */
    private fun getAlbumArtDataUri(albumId: Long): String? {
        if (albumId <= 0L) return null
        return try {
            val artUri = Uri.parse("content://media/external/audio/albumart/$albumId")
            val input = context.contentResolver.openInputStream(artUri) ?: return null
            val original = input.use { BitmapFactory.decodeStream(it) } ?: return null
            val maxSide = 96
            val scale = minOf(maxSide.toFloat() / original.width, maxSide.toFloat() / original.height, 1f)
            val width = maxOf(1, (original.width * scale).toInt())
            val height = maxOf(1, (original.height * scale).toInt())
            val thumbnail = if (width != original.width || height != original.height) {
                Bitmap.createScaledBitmap(original, width, height, true)
            } else original
            val output = ByteArrayOutputStream()
            thumbnail.compress(Bitmap.CompressFormat.JPEG, 62, output)
            if (thumbnail !== original) thumbnail.recycle()
            original.recycle()
            "data:image/jpeg;base64," + Base64.encodeToString(output.toByteArray(), Base64.NO_WRAP)
        } catch (_: Exception) {
            null
        }
    }

    private fun extractFolderName(path: String): String {
        return try {
            val parts = path.split("/")
            if (parts.size >= 2) parts[parts.size - 2] else "Internal Storage"
        } catch (e: Exception) {
            "Audio"
        }
    }

    override fun handleOnDestroy() {
        super.handleOnDestroy()
        mediaPlayer?.release()
        mediaPlayer = null
    }
}
